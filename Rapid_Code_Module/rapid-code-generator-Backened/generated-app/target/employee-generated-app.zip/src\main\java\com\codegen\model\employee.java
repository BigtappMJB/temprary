
package com.codegen.model;


import jakarta.persistence.*;
import java.io.Serializable;

        // No need for import, as Integer is already available
        // No need for import, as String is already available
        // No need for import, as String is already available
        // No need for import, as Character is already available
        import java.sql.Date;

@Entity
@Table(name = "employee")
public class employee implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private Integer Id;
    @Column(name = "Name")
    private String Name;
    @Column(name = "Department")
    private String Department;
    @Column(name = "Gender")
    private Character Gender;
    @Column(name = "DOB")
    private Date DOB;


    public employee() {
    }

    public employee(
        Integer Id, 
        String Name, 
        String Department, 
        Character Gender, 
        Date DOB
    ) {
        this.Id = Id;
        this.Name = Name;
        this.Department = Department;
        this.Gender = Gender;
        this.DOB = DOB;
    }

    public Integer getId() {
        return Id;
    }

    public void setId(Integer Id) {
        this.Id = Id;
    }
    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }
    public String getDepartment() {
        return Department;
    }

    public void setDepartment(String Department) {
        this.Department = Department;
    }
    public Character getGender() {
        return Gender;
    }

    public void setGender(Character Gender) {
        this.Gender = Gender;
    }
    public Date getDOB() {
        return DOB;
    }

    public void setDOB(Date DOB) {
        this.DOB = DOB;
    }

    @Override
    public String toString() {
        return "employee{" +
        "Id=" + Id + ", "  +
        "Name=" + Name + ", "  +
        "Department=" + Department + ", "  +
        "Gender=" + Gender + ", "  +
        "DOB=" + DOB + ""  +
        '}';
    }
}
