-- Auto-generated SQL schema for table employee
-- Run this script in your MySQL or compatible database to create the table

CREATE TABLE IF NOT EXISTS `employee` (
    `Id` INT,
    `Name` VARCHAR(255),
    `Department` VARCHAR(255),
    `Gender` VARCHAR(255),
    `DOB` DATE
    , PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- End of script
