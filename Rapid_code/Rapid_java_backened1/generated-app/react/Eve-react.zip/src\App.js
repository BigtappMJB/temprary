import React from 'react';
import EveCrud from './components/EveCrud';

function App() {
  return (
    <div style={{ margin: 20 }}>
      <EveCrud />
    </div>
  );
}

export default App;