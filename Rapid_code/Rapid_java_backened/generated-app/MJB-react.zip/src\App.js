import React from 'react';
import MJBCrud from './components/MJBCrud';

function App() {
  return (
    <div style={{ margin: 20 }}>
      <MJBCrud />
    </div>
  );
}

export default App;
