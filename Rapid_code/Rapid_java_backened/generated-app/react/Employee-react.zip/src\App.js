import React from 'react';
import EmployeeCrud from './components/EmployeeCrud';

function App() {
  return (
    <div style={{ margin: 20 }}>
      <EmployeeCrud />
    </div>
  );
}

export default App;