import React from 'react';
import EmployeeeCrud from './components/EmployeeeCrud';

function App() {
  return (
    <div style={{ margin: 20 }}>
      <EmployeeeCrud />
    </div>
  );
}

export default App;